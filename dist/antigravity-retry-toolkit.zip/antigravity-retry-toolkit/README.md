# Antigravity Retry Toolkit

Add two capabilities to Antigravity:

- automatically retry temporary cloud capacity failures
- show retry state, recent errors, and quota issues in the bottom status bar

This distribution intentionally does **not** include the floating overlay. It only ships:

- a local retry proxy
- a VS Code / Antigravity status bar extension

## Included files

- `antigravity-cloudcode-proxy.js`
  Local HTTP proxy that retries transient upstream failures and exposes a status endpoint.
- `install-proxy.sh`
  Installs the proxy as a macOS `launchd` user service.
- `uninstall-proxy.sh`
  Removes the proxy service.
- `retry-status-bar-0.2.0.vsix`
  VS Code extension package for the retry status bar.

## Requirements

- macOS
- Antigravity installed
- Node.js installed and available in `PATH`

## What gets retried

- `503`
- transient `429`
- network / transport failures

## What is passed through immediately

- hard quota exhaustion, such as:
  - `You have exhausted your capacity`
  - `quota will reset after ...`

Those are surfaced as `Quota Exceeded` instead of being silently retried forever.

## Retry settings

All retry behavior is configurable through environment variables at install time.

Supported variables:

- `ANTIGRAVITY_PROXY_PORT`
  Local proxy port. Default: `38475`
- `ANTIGRAVITY_PROXY_TARGET_HOST`
  Upstream host. Default: `daily-cloudcode-pa.googleapis.com`
- `ANTIGRAVITY_PROXY_MAX_ATTEMPTS`
  Maximum retry attempts. Default: `15`
- `ANTIGRAVITY_PROXY_BASE_DELAY_MS`
  Initial retry delay in milliseconds. Default: `3000`
- `ANTIGRAVITY_PROXY_MAX_DELAY_MS`
  Maximum retry delay in milliseconds. Default: `10000`
- `ANTIGRAVITY_PROXY_STATUS_HOLD_MS`
  How long to keep the `Recovered` state visible. Default: `5000`
- `ANTIGRAVITY_PROXY_QUOTA_STATUS_HOLD_MS`
  How long to keep the `Quota Exceeded` state visible. Default: `20000`
- `ANTIGRAVITY_PROXY_EVENT_HISTORY_LIMIT`
  Number of recent events kept in memory. Default: `25`

Example:

```bash
export ANTIGRAVITY_PROXY_MAX_ATTEMPTS=20
export ANTIGRAVITY_PROXY_BASE_DELAY_MS=2000
export ANTIGRAVITY_PROXY_MAX_DELAY_MS=15000
./install-proxy.sh
```

## Installation

### 1. Install the local proxy

```bash
chmod +x install-proxy.sh uninstall-proxy.sh
./install-proxy.sh
```

This starts a local service at:

- `http://127.0.0.1:38475`

Health check:

```bash
curl http://127.0.0.1:38475/__health
```

Status endpoint:

```bash
curl http://127.0.0.1:38475/__status
```

### 2. Point Antigravity to the local proxy

Add this to Antigravity user settings:

```json
{
  "jetski.cloudCodeUrl": "http://127.0.0.1:38475"
}
```

Typical file location:

- `~/Library/Application Support/Antigravity/User/settings.json`

### 3. Install the status bar extension

Inside Antigravity, run:

- `Extensions: Install from VSIX...`

Choose:

- `retry-status-bar-0.2.0.vsix`

Then run:

- `Developer: Reload Window`

## Status bar behavior

The status bar can show:

- retry attempts: `1`, `2`, `3`
- hard quota issues: `Quota Exceeded`
- successful recovery: `Recovered`
- idle state: `0`

Hover the status bar item to see:

- current error
- current endpoint
- recent retry / recovery / quota events

Click the status bar item to open:

- `Retry Status Bar` output channel

## Extension settings

The status bar extension also has its own configurable settings:

- `retryStatusBar.statusUrl`
- `retryStatusBar.pollIntervalMs`
- `retryStatusBar.showWhenIdle`
- `retryStatusBar.idleText`
- `retryStatusBar.maxTooltipEvents`

## Logs

Proxy log:

- `~/Library/Logs/antigravity-cloudcode-proxy.log`

## Uninstall

### Remove the proxy

```bash
./uninstall-proxy.sh
```

### Remove the extension

Uninstall this extension from Antigravity:

- `wister-xue.retry-status-bar`

## Troubleshooting

### The status bar item does not appear

Check the following:

1. The extension is installed successfully.
2. You ran `Developer: Reload Window`.
3. `http://127.0.0.1:38475/__status` returns valid JSON.

### Errors still show up in chat

That is expected for:

- hard quota exhaustion
- upstream `500 INTERNAL`
- Antigravity's own session / renderer errors

This toolkit only retries errors that are reasonably likely to succeed on retry.
