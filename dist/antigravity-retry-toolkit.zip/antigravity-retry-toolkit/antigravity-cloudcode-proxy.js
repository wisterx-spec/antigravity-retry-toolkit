#!/usr/bin/env node

const http = require("http");
const https = require("https");

const port = Number(process.env.ANTIGRAVITY_PROXY_PORT || "38475");
const targetHost = process.env.ANTIGRAVITY_PROXY_TARGET_HOST || "daily-cloudcode-pa.googleapis.com";
const maxAttempts = Number(process.env.ANTIGRAVITY_PROXY_MAX_ATTEMPTS || "15");
const baseDelayMs = Number(process.env.ANTIGRAVITY_PROXY_BASE_DELAY_MS || "3000");
const maxDelayMs = Number(process.env.ANTIGRAVITY_PROXY_MAX_DELAY_MS || "10000");
const retryableStatuses = new Set([429, 502, 503, 504]);
const statusHoldMs = Number(process.env.ANTIGRAVITY_PROXY_STATUS_HOLD_MS || "5000");
const quotaStatusHoldMs = Number(process.env.ANTIGRAVITY_PROXY_QUOTA_STATUS_HOLD_MS || "20000");
const eventHistoryLimit = Number(process.env.ANTIGRAVITY_PROXY_EVENT_HISTORY_LIMIT || "25");

let nextEventId = 1;

const runtimeStatus = {
  active: false,
  label: "",
  attempt: 0,
  maxAttempts,
  path: "",
  statusCode: 0,
  message: "",
  updatedAt: 0,
  events: [],
};

function log(message) {
  const now = new Date().toISOString();
  process.stdout.write(`${now} ${message}\n`);
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function setRuntimeStatus(next) {
  Object.assign(runtimeStatus, next, { updatedAt: Date.now() });
}

function pushEvent(event) {
  runtimeStatus.events = [
    ...runtimeStatus.events,
    {
      id: nextEventId++,
      at: Date.now(),
      ...event,
    },
  ].slice(-eventHistoryLimit);
  runtimeStatus.updatedAt = Date.now();
}

function clearRuntimeStatus() {
  setRuntimeStatus({
    active: false,
    label: "",
    attempt: 0,
    path: "",
    statusCode: 0,
    message: "",
  });
}

function beginRetryStatus(path, attempt, statusCode, message) {
  setRuntimeStatus({
    active: true,
    label: String(attempt),
    attempt,
    path,
    statusCode,
    message,
  });
  pushEvent({
    type: "retry",
    path,
    attempt,
    statusCode,
    message,
  });
}

function markRecovered(path) {
  setRuntimeStatus({
    active: false,
    label: "",
    attempt: 0,
    path,
    statusCode: 200,
    message: "Recovered",
  });
  pushEvent({
    type: "recovered",
    path,
    attempt: 0,
    statusCode: 200,
    message: "Recovered",
  });
  setTimeout(() => {
    if (!runtimeStatus.active && runtimeStatus.path === path && runtimeStatus.label === "" && runtimeStatus.message === "Recovered") {
      clearRuntimeStatus();
    }
  }, statusHoldMs);
}

function showQuotaExhausted(path) {
  setRuntimeStatus({
    active: false,
    label: "Quota Exceeded",
    attempt: 0,
    path,
    statusCode: 429,
    message: "Quota Exceeded",
  });
  pushEvent({
    type: "quota",
    path,
    attempt: 0,
    statusCode: 429,
    message: "Quota Exceeded",
  });
  setTimeout(() => {
    if (!runtimeStatus.active && runtimeStatus.path === path && runtimeStatus.label === "Quota Exceeded") {
      clearRuntimeStatus();
    }
  }, quotaStatusHoldMs);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

function readResponseBody(res) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    res.on("data", (chunk) => chunks.push(Buffer.from(chunk)));
    res.on("end", () => resolve(Buffer.concat(chunks)));
    res.on("error", reject);
  });
}

function retryDelayMs(attempt, headers, bodyText) {
  const retryAfter = headers["retry-after"];
  if (retryAfter) {
    const seconds = Number(retryAfter);
    if (Number.isFinite(seconds)) {
      return Math.min(Math.max(seconds * 1000, baseDelayMs), maxDelayMs);
    }
  }

  const bodyMatch = bodyText.match(/reset after (\d+)s/i);
  if (bodyMatch) {
    const seconds = Number(bodyMatch[1]);
    if (Number.isFinite(seconds)) {
      return Math.min(Math.max(seconds * 1000 + 250, baseDelayMs), maxDelayMs);
    }
  }

  return Math.min(baseDelayMs * Math.pow(2, Math.max(0, attempt - 1)), maxDelayMs);
}

function isQuotaExhausted(statusCode, bodyText) {
  if (statusCode !== 429) {
    return false;
  }

  return /quota will reset after/i.test(bodyText) || /exhausted your capacity/i.test(bodyText);
}

function forwardRequest(req, body, attempt) {
  return new Promise((resolve, reject) => {
    const headers = { ...req.headers, host: targetHost };
    if (body.length > 0) {
      headers["content-length"] = String(body.length);
    } else {
      delete headers["content-length"];
    }

    const upstreamReq = https.request(
      {
        protocol: "https:",
        hostname: targetHost,
        port: 443,
        method: req.method,
        path: req.url,
        headers,
      },
      async (upstreamRes) => {
        const statusCode = upstreamRes.statusCode || 0;
        if (retryableStatuses.has(statusCode)) {
          try {
            const responseBody = await readResponseBody(upstreamRes);
            const bodyText = responseBody.toString("utf8");
            if (!isQuotaExhausted(statusCode, bodyText) && attempt < maxAttempts) {
              const delay = retryDelayMs(attempt, upstreamRes.headers, bodyText);
              beginRetryStatus(req.url, attempt, statusCode, `HTTP ${statusCode}`);
              log(`retryable upstream status=${statusCode} attempt=${attempt}/${maxAttempts} delay_ms=${delay} path=${req.url}`);
              await sleep(delay);
              resolve(forwardRequest(req, body, attempt + 1));
              return;
            }

            if (isQuotaExhausted(statusCode, bodyText)) {
              showQuotaExhausted(req.url);
              log(`passthrough quota exhaustion status=${statusCode} attempt=${attempt}/${maxAttempts} path=${req.url}`);
            }

            resolve({ upstreamRes, responseBody });
          } catch (error) {
            reject(error);
          }
          return;
        }

        resolve({ upstreamRes });
      },
    );

    upstreamReq.on("error", async (error) => {
      if (attempt < maxAttempts) {
        const delay = Math.min(baseDelayMs * Math.pow(2, Math.max(0, attempt - 1)), maxDelayMs);
        beginRetryStatus(req.url, attempt, 0, error.message);
        log(`upstream error attempt=${attempt}/${maxAttempts} delay_ms=${delay} path=${req.url} error=${error.message}`);
        await sleep(delay);
        resolve(forwardRequest(req, body, attempt + 1));
        return;
      }
      reject(error);
    });

    if (body.length > 0) {
      upstreamReq.write(body);
    }
    upstreamReq.end();
  });
}

const server = http.createServer(async (req, res) => {
  if (req.url === "/__health") {
    res.writeHead(200, { "content-type": "application/json" });
    res.end(JSON.stringify({ ok: true, targetHost }));
    return;
  }

  if (req.url === "/__status") {
    res.writeHead(200, { "content-type": "application/json", "cache-control": "no-store" });
    res.end(JSON.stringify(runtimeStatus));
    return;
  }

  try {
    log(`request method=${req.method} path=${req.url}`);
    const body = await readBody(req);
    const { upstreamRes, responseBody } = await forwardRequest(req, body, 1);
    const headers = { ...upstreamRes.headers };
    delete headers["content-length"];
    if (runtimeStatus.active && runtimeStatus.path === req.url) {
      markRecovered(req.url);
    }
    log(`response status=${upstreamRes.statusCode} path=${req.url}`);
    res.writeHead(upstreamRes.statusCode || 502, headers);
    if (responseBody) {
      res.end(responseBody);
    } else {
      upstreamRes.pipe(res);
    }
  } catch (error) {
    if (runtimeStatus.path === req.url) {
      setRuntimeStatus({
        active: false,
        label: "Retry Failed",
        path: req.url,
        statusCode: 502,
        message: error.message,
      });
      pushEvent({
        type: "failure",
        path: req.url,
        attempt: 0,
        statusCode: 502,
        message: error.message,
      });
    }
    log(`proxy failure path=${req.url} error=${error.message}`);
    res.writeHead(502, { "content-type": "application/json" });
    res.end(JSON.stringify({ error: "proxy_failure", message: error.message }));
  }
});

server.on("clientError", (error, socket) => {
  log(`client error ${error.message}`);
  socket.end("HTTP/1.1 400 Bad Request\r\n\r\n");
});

server.listen(port, "127.0.0.1", () => {
  log(`antigravity cloud code proxy listening on http://127.0.0.1:${port}`);
});
