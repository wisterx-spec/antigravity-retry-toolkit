#!/bin/zsh
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
NODE_BIN="$(command -v node)"
LABEL="com.wister.antigravity-cloudcode-proxy"
PLIST_PATH="$HOME/Library/LaunchAgents/${LABEL}.plist"
LOG_PATH="$HOME/Library/Logs/antigravity-cloudcode-proxy.log"
PROXY_PORT="${ANTIGRAVITY_PROXY_PORT:-38475}"
TARGET_HOST="${ANTIGRAVITY_PROXY_TARGET_HOST:-daily-cloudcode-pa.googleapis.com}"
MAX_ATTEMPTS="${ANTIGRAVITY_PROXY_MAX_ATTEMPTS:-15}"
BASE_DELAY_MS="${ANTIGRAVITY_PROXY_BASE_DELAY_MS:-3000}"
MAX_DELAY_MS="${ANTIGRAVITY_PROXY_MAX_DELAY_MS:-10000}"
STATUS_HOLD_MS="${ANTIGRAVITY_PROXY_STATUS_HOLD_MS:-5000}"
QUOTA_STATUS_HOLD_MS="${ANTIGRAVITY_PROXY_QUOTA_STATUS_HOLD_MS:-20000}"
EVENT_HISTORY_LIMIT="${ANTIGRAVITY_PROXY_EVENT_HISTORY_LIMIT:-25}"

if [[ -z "${NODE_BIN}" ]]; then
  echo "node not found in PATH"
  exit 1
fi

mkdir -p "$HOME/Library/LaunchAgents" "$HOME/Library/Logs"

cat > "$PLIST_PATH" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>${NODE_BIN}</string>
    <string>${SCRIPT_DIR}/antigravity-cloudcode-proxy.js</string>
  </array>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>WorkingDirectory</key>
  <string>${SCRIPT_DIR}</string>
  <key>EnvironmentVariables</key>
  <dict>
    <key>ANTIGRAVITY_PROXY_PORT</key>
    <string>${PROXY_PORT}</string>
    <key>ANTIGRAVITY_PROXY_TARGET_HOST</key>
    <string>${TARGET_HOST}</string>
    <key>ANTIGRAVITY_PROXY_MAX_ATTEMPTS</key>
    <string>${MAX_ATTEMPTS}</string>
    <key>ANTIGRAVITY_PROXY_BASE_DELAY_MS</key>
    <string>${BASE_DELAY_MS}</string>
    <key>ANTIGRAVITY_PROXY_MAX_DELAY_MS</key>
    <string>${MAX_DELAY_MS}</string>
    <key>ANTIGRAVITY_PROXY_STATUS_HOLD_MS</key>
    <string>${STATUS_HOLD_MS}</string>
    <key>ANTIGRAVITY_PROXY_QUOTA_STATUS_HOLD_MS</key>
    <string>${QUOTA_STATUS_HOLD_MS}</string>
    <key>ANTIGRAVITY_PROXY_EVENT_HISTORY_LIMIT</key>
    <string>${EVENT_HISTORY_LIMIT}</string>
  </dict>
  <key>StandardOutPath</key>
  <string>${LOG_PATH}</string>
  <key>StandardErrorPath</key>
  <string>${LOG_PATH}</string>
</dict>
</plist>
EOF

launchctl enable "gui/$(id -u)/${LABEL}" >/dev/null 2>&1 || true
launchctl bootout "gui/$(id -u)" "$PLIST_PATH" >/dev/null 2>&1 || true
launchctl bootstrap "gui/$(id -u)" "$PLIST_PATH"
launchctl kickstart -k "gui/$(id -u)/${LABEL}" >/dev/null 2>&1 || true

echo "installed proxy: ${PLIST_PATH}"
echo "health: curl http://127.0.0.1:${PROXY_PORT}/__health"
